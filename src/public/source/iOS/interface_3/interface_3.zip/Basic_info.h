//  Basic_info.h
//
//  Created by CodeMan on 2017-02-22
//  Copyright 2012 theotino. All rights reserved.

#import "TNDataModel.h"

@interface Basic_info: TNDataModel

@property (nonatomic, retain) NSString* cover;
@property (nonatomic, retain) NSString* nickname;
@property (nonatomic, retain) NSString* gender;
@property (nonatomic, retain) NSString* avstar_small;
@property (nonatomic, retain) NSString* avstar;

@end