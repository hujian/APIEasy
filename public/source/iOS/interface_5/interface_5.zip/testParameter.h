//  testParameter.h
//
//  Created by CodeMan on 2016-05-05
//  Copyright 2012 theotino. All rights reserved.

#import "TNParametersModel.h"

@interface testParameter : TNParametersModel

@property (nonatomic, retain) NSString *test;

@end
